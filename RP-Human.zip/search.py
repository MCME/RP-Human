import os

def search_for_string_in_files(directory, search_string):
    """
    Recursively searches for a specific string in all files within a directory.

    Args:
        directory (str): The path to the directory to search.
        search_string (str): The string to search for in the files.

    Returns:
        list: A list of file paths containing the search string.
    """
    matching_files = []

    # Walk through the directory structure
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)

            try:
                # Open and read the file
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    if search_string in f.read():
                        matching_files.append(file_path)
            except Exception as e:
                print(f"Error reading file {file_path}: {e}")

    return matching_files

if __name__ == "__main__":
    # Use the current working directory as the resource pack path
    resource_pack_path = os.getcwd()
    search_string = "unused_block_0"

    print("Searching for files containing the string 'builtin/entity'...")
    results = search_for_string_in_files(resource_pack_path, search_string)

    if results:
        print("\nFound the string in the following files:")
        for file in results:
            print(file)
    else:
        print("\nNo files containing the string were found.")
