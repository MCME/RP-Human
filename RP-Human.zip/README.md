# RP-Human
The official repository for MCME's Human resource pack.
Created by members of the Minecraft Middle-Earth community.

Latest release is available at 
https://www.mcmiddleearth.com/community/resources/categories/official-resourcepacks.9/

>Website: https://www.mcmiddleearth.com

>Discord: https://discord.gg/mcmiddleearth

>Discussions take place at Discord or https://www.mcmiddleearth.com/community/forums/textures.37/

This resourcepack and all its forks fall under the Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) license.

The complete license can be found at http://creativecommons.org/licenses/by-nc-sa/4.0/
