# RP-Gondor
The official repository for MCME's Gondor pack.
Created by members of the Minecraft Middle-Earth community.

THIS IS A RESOURCEPACK IN DEVELOPMENT AND THEREFORE SHOULD NOT BE DOWNLOADED AND USED ON OUR SERVERS.
RESOURCEPACKS HERE ARE SUBJECT TO A QUALITY CONTROL PROCESS BEFORE THEY CAN BE USED.
ONLY USE THE RESOURCEPACKS WHICH ARE AUTOMATICALLY SUPPLIED TO YOU BY THE SERVER, OR THE ONES
AVAILABLE AT https://www.mcmiddleearth.com/community/resources/categories/official-resourcepacks.9/

>Website: https://www.mcmiddleearth.com

>Discussions take place at https://www.mcmiddleearth.com/community/forums/textures.37/

This resourcepack and all its forks fall under the Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) license.

The complete license can be found at http://creativecommons.org/licenses/by-nc-sa/4.0/
